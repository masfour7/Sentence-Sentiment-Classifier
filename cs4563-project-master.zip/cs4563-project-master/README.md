# cs4563-project
Sentence Sentiment Classifier Project for CS-UY 4563 (S'20)

First notebook shows results from a pre-trained word2vec model

Second notebook shows results of our own word2vec trained model
